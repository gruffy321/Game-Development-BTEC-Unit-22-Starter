﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstUnityScriptDebugLog : MonoBehaviour 
{

/// <summary>
/// One of the first things to note is that in the Game Engine IDE
/// We can see and have access to our variable in a window called the Inspector.
/// When we place a valid script onto a GameObject, it will show up in the inspector window
/// and can be viewed there also.
/// However, we are going to simply decalre and intitialise a variable or two
/// and show any changes we make in code to the Console window in the Unity IDE. 
/// </summary>

//decs
	public int testNumber = 69;

	// Use this for initialization
	void Start () 
	{
		Debug.Log(2*2);
		Debug.Log("This was the test number " + testNumber);
		Debug.Log("This was the test number with 9 added " +  (testNumber + 9));
		Debug.Log("This was the test number after minusing itself from itself " + (testNumber - testNumber));
	}
	
	// Update is called once per frame
	void Update () 
	{
		//..In Start(), did you note the number of times the console caught the Logs we executed?
		//check it and see it happen once, and only once!
		//move your code in Start() over to here and then watch the Console Panel window in the Unity Editor
		//place that code under here...

	}
}
