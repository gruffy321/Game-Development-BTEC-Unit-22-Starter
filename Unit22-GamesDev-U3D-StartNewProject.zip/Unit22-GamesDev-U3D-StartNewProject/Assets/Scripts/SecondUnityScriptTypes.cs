﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondUnityScriptTypes : MonoBehaviour {

///<summary>
/// As with vanilla C#, C# for Unity has types both common value types, common complex value types and common complex reference types.
/// below is a number of types that can be found as used commonly in Unity3D, we will discuss them in order.
/// 
///</summary>

//decs examples
//COMMON VALUE TYPE EXAMPLES
public int wholeNumber;
uint positiveWholeNumber;
float fractionalNumber;

string textOrSentence = " "; //in general, strings are best, and often have to be anyway, initialised to something at the point of declaration (THEY ARE ACTUALLY REF TYPES, WHAT DOES ALL THIS MEAN?)

//COMPLEX VALUE TYPE EXAMPLE
struct MapCoordinateXY
{
	public int mapX;	
	public int mapY;
	public string GetMapCoordinates()
	{
		string result = mapX.ToString() + " " + mapY.ToString();
		return result;
	}
}
//Once we have made a primitve type like the struct, we then have to declare it like any other variable
//its good practice to declare the variable version after the struct declaration to keep things tidy


//COMPLEX REFERENCE TYPE EXAMPLE
// Complex types are classes and are instantiated as living instances of the blueprint/template the class gave to it.
// Classes always go through a three(3) step process to becomgin something in the game.
// They are very often initialised and instanced together when coded in...

//      Declaration******************
MyObject complexObjectBuiltFromAClass;
//end all decs examples

/// <summary>
/// Using the inbuilt start or Update loops, we can test some of these variables out with the Debug.Log(); command.
/// 
/// </summary>

/// <summary>
/// Start is called on the frame when a script is enabled just before
/// any of the Update methods is called the first time.
/// </summary>
	void Start()
	{
		//inits for any value types 
		wholeNumber = -5;
		positiveWholeNumber = 98;
		fractionalNumber = 5.765123f;
		textOrSentence = "Welcome to C# in Unity SDC Level 3 Year 2: Unit 22";
		MapCoordinateXY mapCoordinateXY;
		mapCoordinateXY.mapX = 10;
		mapCoordinateXY.mapY = 15;
		
		//object ********************instantiation*** any constructors initialisations
		complexObjectBuiltFromAClass = new MyObject(40, "Gruff");
		string objectDetails = complexObjectBuiltFromAClass.GetObjectDetails();
		string mapCoords = mapCoordinateXY.GetMapCoordinates();
		
		string finalSentence = string.Format("The whole number {0}, followed by the pos whole number {1},\nWith a fractional number of {2}, \nYour map position is {3} and there's a sentence saying {4}\n Where wouldl you like to go {5} ",wholeNumber, positiveWholeNumber, fractionalNumber, mapCoords, textOrSentence, objectDetails );
		Debug.Log(finalSentence);
	}
}

//self made class - see how this sits outside the actual script class.
//this identifes that you can actually have lots of classes in one script,
//but this is really poor organisation of code and only to be used in circumstances
//where it might make sense to have them local for developemnt purposes or they are particularly small classes for instance.
//but essential to be a class(because of the need for many instances of it; obvs)
public class MyObject
{
	private int age;
	private string name;
	//class contructor with input parameters that need to be filled with the correct arguments.
	public MyObject(int _age, string _name)
	{
		age = _age;
		name = _name;
	}
	//classic implementation of a class method available to the instantiated object, 
	//so it can have the age and name retrieved when asked for
	//no parmamters, just a method call publically available to any instance of this class.
	public string GetObjectDetails()
	{
		string sendBackDetails = ("The age of the object is " + age.ToString() + "\nThe name of the object is " + name);
		return sendBackDetails;
	}
}
