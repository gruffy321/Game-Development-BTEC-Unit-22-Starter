﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LearningScript : MonoBehaviour 
{

	/// <summary>
	/// we can declare our variables at the top as part of a good practice and readibility
	/// This keep things organised and makes it easy for us to see if anythign need further attention
	/// </summary>


	// Give yourself an area for delarations & initialisations, if required with comments like so.

	//declarations - all "class available" new variables go under here

	//end decs

	//initialisations - all "class available" variables that need a starting value 
	//go under here

	//end variable inits



	/// <summary>
	/// Start Method is where we can set up any variables once the script is loaded
	/// Or where we can access and control any other already created GameObjects in the game 
	/// 
	/// </summary>
	void Start ()
	{
		
	}
	
	// Update is called once per frame and is the main method that actually pipelines your code and content into a mutilple loop
	//...called the Game Loop. This is a traditioanl loop found in any game at the heart and consists:
	//...at the minimum 3 main processes during every frame INPUT loop, UPDATE loop & RENDER loop
	// WE ARE EXTREMELY LUCKY THAT WE ONLY HAVE TO ADDRESS THE UPDATE LOOP TO MAKE CHANGES.
	//Anything we want to consider for input, render or game logic changes can all be executed via
	//this one loop: Update(){}
	void Update () 
	{
		
	}

	/// <summary>
	/// SO, THAT SUMMARISES A C# SCRIPT CLASS IN UNITY.
	/// We can see that there are specific methods handed to us and we are encouraged to use them to get things happening
	/// ...in our games.!--
	/// Our next class will see us creating small lines of code to execute during Play Mode
	/// We will see the results in the Console, a place to debug your code and see functionality happening
	/// without the need to create lots of game assets first.!--  
	/// </summary>
}
